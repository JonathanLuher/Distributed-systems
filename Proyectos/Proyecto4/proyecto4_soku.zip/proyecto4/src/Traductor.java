import java.net.*;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import com.google.gson.*;

public class Traductor {
    private static final String API_KEY = "AIzaSyBplp2QnI1QgdCP3jIudkzverqBIkmY8V4";
    
    public static String traducir(String texto, String palabra) {
        try {
            String textoMarcado = texto.replaceAll("(?i)" + palabra, "☼" + palabra + "☼");
            String url = "https://translation.googleapis.com/language/translate/v2" +
                       "?key=" + API_KEY + "&target=es&q=" + 
                       URLEncoder.encode(textoMarcado, StandardCharsets.UTF_8);
            
            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .build();
            
            HttpResponse<String> response = HttpClient.newHttpClient()
                .send(request, HttpResponse.BodyHandlers.ofString());
            
            JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
            String traduccion = json.getAsJsonObject("data")
                .getAsJsonArray("translations")
                .get(0).getAsJsonObject()
                .get("translatedText").getAsString();
            
            return traduccion.replace("☼" + palabra + "☼", "\u001B[32m" + palabra + "\u001B[0m");
        } catch(Exception e) {
            return "[Error de traducción]";
        }
    }
}