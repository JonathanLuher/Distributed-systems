import com.google.cloud.firestore.*;
import com.google.gson.*;
import com.sun.net.httpserver.*;
import java.io.*;
import java.net.InetSocketAddress;
import java.util.*;

public class SearchService {
    private static final Firestore db = FirestoreOptions.getDefaultInstance().getService();
    private static final Gson gson = new Gson();
    private static final Map<String, Integer> contadorGlobal = new HashMap<>();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        server.createContext("/buscar", new BuscarHandler());
        server.start();
        System.out.println("Servidor escuchando en puerto 8080");
    }

    static class BuscarHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try (InputStream is = exchange.getRequestBody();
                 OutputStream os = exchange.getResponseBody()) {
                
                String requestBody = new String(is.readAllBytes());
                JsonObject request = JsonParser.parseString(requestBody).getAsJsonObject();
                
                String palabra = request.get("palabra").getAsString().toLowerCase();
                int ocurrencia = contadorGlobal.getOrDefault(palabra, 0);
                contadorGlobal.put(palabra, ocurrencia + 1);
                
                Query query = db.collection("libros")
                    .where("indice." + palabra, ">", Collections.emptyList());
                
                JsonArray resultados = new JsonArray();
                for (DocumentSnapshot doc : query.get().get().getDocuments()) {
                    List<Integer> posiciones = doc.get("indice." + palabra, List.class);
                    if (posiciones.size() > ocurrencia) {
                        int pos = posiciones.get(ocurrencia);
                        List<String> oraciones = doc.get("oraciones", List.class);
                        
                        JsonObject item = new JsonObject();
                        item.addProperty("titulo", doc.getString("titulo"));
                        item.addProperty("ingles", resaltar(oraciones.get(pos), palabra));
                        item.addProperty("espanol", Traductor.traducir(oraciones.get(pos), palabra));
                        resultados.add(item);
                    }
                }
                
                exchange.getResponseHeaders().add("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, 0);
                os.write(gson.toJson(resultados).getBytes());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        private String resaltar(String texto, String palabra) {
            return texto.replaceAll("(?i)" + palabra, "\u001B[32m$0\u001B[0m");
        }
    }
}