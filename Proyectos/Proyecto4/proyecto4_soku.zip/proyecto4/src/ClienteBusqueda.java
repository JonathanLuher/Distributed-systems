import java.net.*;
import java.net.http.*;
import java.util.*;
import com.google.gson.*;

public class ClienteBusqueda {
    private static final HttpClient client = HttpClient.newHttpClient();
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while(true) {
            System.out.print("\n\u001B[36mPalabra a buscar > \u001B[0m");
            String palabra = scanner.nextLine().trim();
            if(palabra.isEmpty()) continue;
            
            try {
                String json = buscarPalabra(palabra);
                mostrarResultados(JsonParser.parseString(json).getAsJsonArray(), palabra);
            } catch(Exception e) {
                System.out.println("\u001B[31mError: " + e.getMessage() + "\u001B[0m");
            }
        }
    }
    
    private static String buscarPalabra(String palabra) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("http://35.197.26.247:8080/buscar"))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(
                "{\"palabra\":\"" + palabra + "\"}"))
            .build();
        
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }
    
    private static void mostrarResultados(JsonArray resultados, String palabra) {
        System.out.println("\n\u001B[34m=== Se encontró '" + palabra + "' en " + 
                          resultados.size() + " documentos ===\u001B[0m");
        
        for(JsonElement r : resultados) {
            JsonObject item = r.getAsJsonObject();
            System.out.println("\n\u001B[33m◆ Título: " + item.get("titulo").getAsString() + "\u001B[0m");
            System.out.println("\u001B[36mEN:\u001B[0m " + item.get("ingles").getAsString());
            System.out.println("\u001B[35mES:\u001B[0m " + item.get("espanol").getAsString());
        }
    }
}