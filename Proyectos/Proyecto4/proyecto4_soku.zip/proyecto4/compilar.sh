#!/bin/bash

LIBS="lib/*"
SRC="src/*.java"
DEST="bin"

mkdir -p bin
javac -cp "$LIBS" -d $DEST $SRC
