package deep;

import com.google.cloud.firestore.*;
import com.google.gson.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ExecutionException;
import com.sun.net.httpserver.*;

public class SearchService {
    private static final Gson gson = new Gson();
    private static Firestore db = FirestoreClient.getFirestore();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8081), 0);
        server.createContext("/buscar", new BuscarHandler());
        server.setExecutor(null);
        server.start();
        System.out.println("Servidor iniciado en puerto 8081");
    }

    static class BuscarHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            try {
                String requestBody = new String(exchange.getRequestBody().readAllBytes());
                JsonObject request = JsonParser.parseString(requestBody).getAsJsonObject();
                
                String palabra = request.get("palabra").getAsString().toLowerCase();
                int ocurrencia = request.get("ocurrencia").getAsInt();
                
                QuerySnapshot query = db.collection("libros")
                    .whereArrayContains("palabras", palabra)
                    .get().get();
                
                JsonArray resultados = new JsonArray();
                
                for(QueryDocumentSnapshot documento : query) {
                    JsonObject libro = new JsonObject();
                    libro.addProperty("titulo", documento.getString("titulo"));
                    
                    List<String> oraciones = documento.get("oraciones", List.class);
                    List<String> posiciones = documento.get("indice." + palabra, List.class);
                    
                    if(posiciones != null && posiciones.size() > ocurrencia) {
                        int posicion = Integer.parseInt(posiciones.get(ocurrencia));
                        String ingles = oraciones.get(posicion);
                        
                        libro.addProperty("ingles", ingles);
                        libro.addProperty("espanol", Traductor.traducir(ingles));
                        resultados.add(libro);
                    }
                }
                
                enviarRespuesta(exchange, resultados.toString());
            } catch(Exception e) {
                enviarError(exchange, "Error: " + e.getMessage());
            }
        }
        
        private void enviarRespuesta(HttpExchange exchange, String respuesta) throws IOException {
            exchange.sendResponseHeaders(200, respuesta.getBytes().length);
            try(OutputStream os = exchange.getResponseBody()) {
                os.write(respuesta.getBytes());
            }
        }
        
        private void enviarError(HttpExchange exchange, String error) throws IOException {
            exchange.sendResponseHeaders(500, error.getBytes().length);
            try(OutputStream os = exchange.getResponseBody()) {
                os.write(error.getBytes());
            }
        }
    }
}